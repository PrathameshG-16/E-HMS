package DataDriven;

import java.util.concurrent.TimeUnit;

//import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataD1 {
	WebDriver driver;

	@Test(dataProvider = "testdata")
	public void setupClass(String username, String password) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\ghorpade.vishal\\Downloads\\chromedriver_win32");
		 driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.name("user-name")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/input")).click();

	}

	@DataProvider(name = "testdata")
	public Object[][] testDataExample() {

		ReadExcelFile configuration = new ReadExcelFile(
				"C:\\Users\\ghorpade.vishal\\OneDrive - HCL Technologies Ltd\\Documents\\ExportDataDriven.xlsx");
		int rows = configuration.getRowCount(0);
		Object[][] signin = new Object[rows][2];

		for (int i = 0; i < rows; i++) {
			signin[i][0] = configuration.getData(0, i, 0);
			signin[i][1] = configuration.getData(0, i, 1);

		}
		return signin;
	}
}
