package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

 

public class LoginSauce {
    private static final By Cancel = null;
	private static final By Finish = null;
	WebDriver driver;
    By uname = By.name("user-name");
    By pass  = By.name("password");
    By login = By.xpath("/html/body/div/div/div[2]/div[1]/div[1]/div/form/input");
    By title = By.xpath("/html/body/div/div/div/div[2]/div/div/div/div[1]/div[2]/div[1]/a/div");
    By Add = By .xpath("/html/body/div/div/div/div[2]/div/div/div[2]/button");
    By AtoZ = By.cssSelector("#header_container > div.header_secondary_container > div.right_component > span > select");
    By cart = By.xpath("/html/body/div/div/div/div[1]/div[1]/div[3]/a");
    By Checkout = By.cssSelector("#checkout");
    By Lines = By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[1]/div/button");
    By Firstname = By.cssSelector("#first-name");
    By Lastname = By.cssSelector("#last-name");
    By Postalcode = By.cssSelector("#postal-code");
    By Continue = By.id("continue");
    By Cancel1 = By.id("cancel");
    By Finish1 = By.id("finish");
    By Logout = By.xpath("/html/body/div/div/div/div[1]/div[1]/div[1]/div/div[2]/div[1]/nav/a[3]");
   // By DropDown = By.cssSelector("#header_container > div.header_secondary_container > div.right_component > span > select");
    public LoginSauce(WebDriver driver) {
        this.driver = driver;
    }

 

    public void setUname(String username) {
        driver.findElement(uname).sendKeys(username);
    }

 

    public void setPass(String passWord) {
        driver.findElement(pass).sendKeys(passWord);
    }

 

    public void setclick() {
        driver.findElement(login).click();
    }
    public void setTclick() {
        driver.findElement(title).click();
    }
    
    public void setAddclick() {
        driver.findElement(Add).click();
    }
    
    public void setAtoZclick() {
        driver.findElement(AtoZ).click();
    }
    
    
    public void setcartclick() {
        driver.findElement(cart).click();
    }
    
    
    
    public void setCheckoutclick() {
        driver.findElement(Checkout).click();
    }
    
    public void setLogClick() {
        driver.findElement(Logout).click();
        //TODO Auto-generated method stub

    }



	public void setClick() {
		// TODO Auto-generated method stub
		driver.findElement(Lines).click();
		
	}
	 public void setFirstname(String Yesh) {
		 driver.findElement(By.cssSelector("#first-name")).sendKeys("Yesh");
	    }
	 
	 public void setLastname(String Reddy) {
		 driver.findElement(By.cssSelector("#last-name")).sendKeys("Reddy");
	    }
	 public void setPostalcode(String postal) {
		 driver.findElement(By.cssSelector("#postal-code")).sendKeys("postal");
	    }
	 public void setContinueclick() {
		 driver.findElement(By.cssSelector("#continue")).click();
	 }
	 
	  
	 
	 public void setFinishclick() {
	        driver.findElement(Finish).click();
	 }



	public Object navigate() {
		// TODO Auto-generated method stub
		return null;
	}



	//public void setDropDownMenu(String string) {
		// TODO Auto-generated method stub
		//driver.findElement(DropDown).isSelected();
		
	}


