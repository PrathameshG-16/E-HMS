package Saucepages;

import java.util.concurrent.TimeUnit;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
//POM
public class SauceBrowser {
    static WebDriver driver;

    public static WebDriver StartBrowser(String Browser, String url) {
        if (Browser.equalsIgnoreCase("eb")) {

        	System.setProperty("webdriver.edge.driver", "C:\\Users\\gudipati.yeshwanth\\Downloads\\edgedriver_win64\\msedgedriver.exe");
              driver = new EdgeDriver();
                driver.manage().window().maximize();
              //  driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        }
        else if (Browser.equalsIgnoreCase("cb")) {
        	System.setProperty("webdriver.chrome.driver", "C:\\Users\\gudipati.yeshwanth\\Downloads\\chromedriver_win32\\chromedriver.exe");
              driver = new ChromeDriver();
                driver.manage().window().maximize();

        }
        driver.get(url);
         driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
         return driver;
    }

 

}
