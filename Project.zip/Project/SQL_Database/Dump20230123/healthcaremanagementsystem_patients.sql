-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthcaremanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `PatientID` int NOT NULL,
  `First_Name` varchar(30) DEFAULT NULL,
  `Last_Name` varchar(30) DEFAULT NULL,
  `Gender` varchar(5) DEFAULT NULL,
  `ContactNumber` varchar(11) DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `EmailID` varchar(30) DEFAULT NULL,
  `BloodGroup` varchar(50) DEFAULT NULL,
  `Address` varchar(50) NOT NULL,
  PRIMARY KEY (`PatientID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Sanjay','Gosavi','M','9828698648',28,'sanjay24gosavi@gmail.com','B+','D-402 Anand Nagar M.I. road Delhi'),(2,'Anand','Sharma','M','9858688788',30,'anand54sharma@gmail.com','B+','E-002 Tilak Nagar New Delhi'),(3,'Subhash','Garg','M','9667479292',34,'gargsubash1703@gmail.com','A+','Basant Vihar Pune'),(4,'Priya','Khandelwal','F','8005629518',28,'sanjay24gosavi@gmail.com','B-','PlotNo. 104 Subhash chowk Chandigarh'),(5,'Pritam','Yadav','M','9828652524',18,'letsmailprit02@gmail.com','AB+','C-03 Vaishali Nagar Jaipur'),(6,'Sanju','Sharma','M','9279264253',42,'sansharma8@gmail.com','B-','Gopal Nagar Bharatpur'),(7,'Tejaswani','Goswami','F','8005263213',32,'goswamiteja@gmail.com','A-','Prasad Dham Mumbai'),(8,'Sumit','Bhardwaj','M','8214358648',46,'sumit4566bhardwaj@gmail.com','O+','Surya Path Roorki'),(9,'Kavita','Jain','F','9825426363',15,'jain78kavi@gmail.com','AB+','Gaurav Path M.I. road Delhi'),(10,'Yogesh','Sihra','M','9828565642',28,'yogeshshira28@gmail.com','AB-','Durgapur road Kolkatta'),(11,'Bhanu','Pratap','M','8052674312',68,'bahnupratap@gmail.com','O+','vivekanand street Malipura'),(12,'Sonam','Tiwari','F','9797465823',18,'sonamtiwari423@gmail.com','A+','E-03 Tonk Phatak Jaipur'),(13,'Neha','Mehta','F','7073165498',24,'mehtaneha556@gmail.com','AB-','rani chawk jalandhar'),(14,'Roop','Devi','F','8302567823',56,'roopdevima@gmail.com','B-','Chandni chawak Delhi'),(15,'Yash','Chaudary','M','9886756678',36,'chaudaryash011@gmail.com','AB+','Rashi Mansion Indore'),(16,'Suraj','Yadav','M','8308576312',24,'itssuraj@gmail.com','A+','Usha vihar bhilwada'),(17,'Arjun','Sethi','M','7782385721',42,'arjun11sethi@gmail.com','B+',' Flat no.33 Behind Uday Street Bhopal'),(18,'Priya','Goyal','F','8857283942',32,'angelpriya@gmail.com','A-','Bajri Mandi Gandhi Path Kota'),(19,'Aanvi','Singhal','F','9815215367',12,'aanvisinghal100@gmail.com','B-','Chhatrapati Shivaji Mansion Mumbai'),(20,'Rohit','Singh','M','8358032156',27,'rohitsingh124@gmail.com','O+','Ganesh Vihar Mudrai'),(21,'Pratham','Ghorpade','m','1122334455',18,'pratham@','b+','R'),(22,'Abhishek','C','M','1122334499',18,'ABHI','A+','R'),(25,'Yeshwanth','G','m','22333',19,'Yg','b','ds'),(26,'Raj','Kumar','M','9900110011',32,'RajKumar@gmail.com','B+','GM');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-23 16:11:31
