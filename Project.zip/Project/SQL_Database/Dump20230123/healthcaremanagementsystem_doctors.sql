-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthcaremanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `DoctorID` int NOT NULL,
  `First_Name` varchar(30) DEFAULT NULL,
  `Last_Name` varchar(30) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `ContactNumber` varchar(11) DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `Entry_Charge` int DEFAULT NULL,
  `Qualification` varchar(50) DEFAULT NULL,
  `Doctor_Type` varchar(50) DEFAULT NULL,
  `Email_Id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`DoctorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'Vivek','Bhardwaj','M','9243668213',32,400,'MD','Ear','bhardwajvivek@gmail.com'),(2,'Vinod','Gupta','M','9382674321',42,300,'BDS','Lungs','vinod24gupta@gmail.com'),(3,'Ashish','Arora','M','8213264251',47,200,'BHMS','Eye','arorashish5871@gmail.com'),(4,'Poonam','Mishra','F','7782934712',27,700,'MD','Kidney','punamishra@gmail.com'),(5,'Madhu','Srivastva','F','9982675837',33,500,'MD','Heart','srivastvamadhu@gmail.com'),(6,'Anoop','Faujdar','M','9788855387',58,550,'MBBS','Lungs','anoopfauji@gmail.com'),(7,'Ankita','Khandelwal','F','9985671358',36,300,'BAMS','General_Physicist','khandelwalankita@gmail.com'),(8,'Abhishek','Agarwal','M','8763505789',25,200,'Phd','Kidney','abhishekagarwal25@gmail.com'),(9,'Piyush','Gupta','M','7855671213',52,400,'MBBS','Heart','piyushgupta562@gmail.com'),(10,'Priyanka','Jangid','F','8005628135',68,600,'BDS','Lungs','prinyanka456jangid@gmail.com'),(11,'Deepak','Sharma','M','9505745565',38,250,'MS','General_Physicist','dipakshramtalks@gmail.com'),(12,'Prakash','Yadav','M','9460812415',47,350,'BAMS','Eye','yadavprakash79@gmail.com'),(13,'Harish','Chauhan','M','9855762432',54,450,'PhD','Ear','harishchauhanstarts@gmail.com'),(14,'Seema','Patodi','F','9651404283',63,500,'BHMS','Bone','meseemapatodi@gmail.com'),(15,'Mukesh','Saxena','M','9887635723',69,450,'BUMS','Bone','saxenamukesh@gmail.com'),(16,'Ashok','Gupta','M','9988735721',29,300,'BDS','Ear','ashokgupta@gmail.com'),(17,'Ashish','Maheshwari','M','7082172315',35,300,'MBBS','Heart','maheswariashish@gmail.com'),(18,'Neelam','rao','F','9652385745',39,350,'MD','Kidney','raoneelam46@gmail.com'),(19,'Priyanka','Sharma','F','8857638923',24,250,'BDS','Lungs','priyanka24sharma@gmail.com'),(20,'Gaurav','Tripathi','M','8112857382',40,400,'MBBS','Heart','gaurav00tripathi@gmail.com'),(25,'abhi','rajput','m','1222',22,200,'bsc','General Physicist','abhir');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-23 16:11:28
