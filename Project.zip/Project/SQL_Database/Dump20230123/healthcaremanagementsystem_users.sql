-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthcaremanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userID` int NOT NULL,
  `userType` varchar(100) NOT NULL,
  `Password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userID`,`userType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Doctor','One'),(1,'Patient','One'),(2,'Doctor','Two'),(2,'Patient','Two'),(3,'Doctor','Three'),(3,'Patient','Three'),(4,'Doctor','Four'),(4,'Patient','Four'),(5,'Doctor','Five'),(5,'Patient','Five'),(6,'Doctor','Six'),(6,'Patient','Six'),(7,'Doctor','Seven'),(7,'Patient','Seven'),(8,'Doctor','Eight'),(8,'Patient','Eight'),(9,'Doctor','Nine'),(9,'Patient','Nine'),(10,'Doctor','Ten'),(10,'Patient','Ten'),(11,'Doctor','Eleven'),(11,'Patient','Eleven'),(12,'Doctor','Twelve'),(12,'Patient','Twelve'),(13,'Doctor','Thirteen'),(13,'Patient','Thirteen'),(14,'Doctor','Fourteen'),(14,'Patient','Fourteen'),(15,'Doctor','Fifteen'),(15,'Patient','Fifteen'),(16,'Doctor','Sixteen'),(16,'Patient','Sixteen'),(17,'Doctor','Seventeen'),(17,'Patient','Seventeen'),(18,'Doctor','Eighteen'),(18,'Patient','Eighteen'),(19,'Doctor','Nineteen'),(19,'Patient','Nineteen'),(20,'Doctor','Twenty'),(20,'Patient','Twenty'),(21,'Doctor','112233'),(21,'Patient','1122'),(22,'Doctor','abc1'),(22,'Patient','1133'),(23,'Doctor','abbbcc'),(24,'Doctor','aabb'),(25,'Doctor','qqq'),(25,'Patient','11ee'),(26,'Patient','1ww1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-23 16:11:39
