package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FactoryPageOrangeHRM {
	
	WebDriver driver;
	@FindBy(name = "username") WebElement uname;
	@FindBy(name = "password") WebElement psw;
	@FindBy(css ="#app > div.orangehrm-login-layout > div > div.orangehrm-login-container > div > div.orangehrm-login-slot > div.orangehrm-login-form > form > div.oxd-form-actions.orangehrm-login-action > button" ) 
	WebElement Lb;
	public void setUname(String uid) {
		uname.sendKeys(uid);
		
		
	}
	public void setpsw(String pass) {
		psw.sendKeys(pass);
	
		
	}
	public void clickLb() {
		Lb.click();
		
		
	}
	
	


}
