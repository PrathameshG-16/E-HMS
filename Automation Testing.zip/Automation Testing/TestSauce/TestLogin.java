package TestSauce;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Saucepages.SauceBrowser;
import pages.LoginSauce;

public class TestLogin {
	 LoginSauce obj;
	    WebDriver driver;
	    String baseurl = "https://www.saucedemo.com/";

	    @BeforeTest
	    public void setUp() {
	        driver = SauceBrowser.StartBrowser("eb", baseurl);
	    }
	    
	    //VALID INPUT
	    @Test
	    public void logintest() {
	        obj = new LoginSauce(driver);
	        obj.setUname("standard_user");
	        obj.setPass("secret_sauce");
	        obj.setclick();
	        obj.setClick();
	        obj.setLogClick();
	      
	    }
	    
	  //VALID INPUT
	    @Test (priority = 1) 
	    public void logintest1() {
	    	 obj = new LoginSauce(driver);
		        obj.setUname("locked_out_user");
		        obj.setPass("secret_sauce");
		        obj.setclick();
		       // obj.setClick();
		        //obj.setLogClick();
		        driver.navigate().refresh();
		              	
	    }
	    
	  //VALID INPUT
	    @Test (priority = 2) 
	    public void logintest2() {
	    	 obj = new LoginSauce(driver);
		        obj.setUname("problem_user");
		        obj.setPass("secret_sauce");
		        obj.setclick();
		        obj.setClick();
		        obj.setLogClick();
		          
	    }
	    
	  //VALID INPUT
	    @Test (priority = 3) 
	    public void logintest3() {
	    	 obj = new LoginSauce(driver);
		        obj.setUname("performance_glitch_user");
		        obj.setPass("secret_sauce");
		        obj.setclick();
		        obj.setClick();
		        obj.setLogClick();
		             
	    }
	    
	  //INVALID USERNAME
	    @Test (priority = 4)
	    public void logintest4() {
	        obj = new LoginSauce(driver);
	        obj.setUname("stand_user");
	        obj.setPass("secret_sauce");
	        obj.setclick();
	       // obj.setClick();
	       // obj.setLogClick();
	        driver.navigate().refresh();
	        
	       	    }
	    
	  //INVALID PASSWORD
	    @Test (priority = 5)
	    public void logintest5() {
	        obj = new LoginSauce(driver);
	        obj.setUname("standard_user");
	        obj.setPass("student_sauce");
	        obj.setclick();
	        //obj.setClick();
	       // obj.setLogClick();
	        driver.navigate().refresh();
	        
	        
	    }
	    
	  //INVALID USERNAME AND PASSWORD
	    @Test (priority = 6)
	    public void logintest6() {
	        obj = new LoginSauce(driver);
	        obj.setUname("stand_user");
	        obj.setPass("student_sauce");
	        obj.setclick();
	       // obj.setClick();
	       // obj.setLogClick();
	        driver.navigate().refresh();
	         
	    }
	    
	  //VALID INPUT
	    @Test (priority = 7)
	    public void logintest7() {
	        obj = new LoginSauce(driver);
	        obj.setUname("standard_user");
	        obj.setPass("secret_sauce");
	        obj.setclick();
	        obj.setTclick();
	        obj.setClick();
	        obj.setLogClick();
	        
	    }
	    
	  //VALID INPUT
	   @Test (priority = 8)
	    public void logintest8() {
	        obj = new LoginSauce(driver);
	        obj.setUname("standard_user");
		     obj.setPass("secret_sauce");
		      obj.setclick();
		      obj.setTclick();
		        obj.setAddclick(); 
		        obj.setClick();
		        obj.setLogClick();
	    }
	  
	    
	  //VALID INPUT
	    @Test (priority = 9) 
	    public void logintest9() {
	    	 obj = new LoginSauce(driver);
		        obj.setUname("problem_user");
		        obj.setPass("secret_sauce");
		        obj.setclick();
		        obj.setClick();
		        obj.setcartclick();
		        obj.setCheckoutclick();
		       obj.setFirstname("Yesh");
		       obj.setLastname("Reddy");
		       obj.setPostalcode("postal");
		       obj.setContinueclick();
		      
		       
		        
	    }
	    
	    	
	    	
	    
	    @AfterTest
	    public void tearDown() {
	        driver.quit();
	    }
}

